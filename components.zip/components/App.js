import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { Informacoes } from './src/components/informacoes/index.js';
import { Cabecalho } from './src/components/cabecalho/cabecalho.js';

export default function App() {
  let infos = [
    { 
      endereco: `Rua Alvaro da Costa, 251. 08461-420`,
      telefone: `(11) 9 3427-8063`,
      email: `leozinhodomilgrau@gmail.com`,
      site: `www.cavalo.com.br`, 
    },
    {
      exp1: `Sema Academia LTDA (2025-2026) Recepcionista`,
      exp2: `Relancer de Designer Grafico (Atual)`,
    },
    { 
      form1: `Ensino fundamental - Colegio Arruda Persset (concluido)`,
      form2: `Ensino Medio Tecnico - Etec de Cidade Tiradentes (cursando) desenvolvimento de sistemas`,
    },
    {
      hab1: `Dominio em Software de edição`,
      hab2: `Criatividade em projetos visuais `,
      hab3: `Escuta ativa para os relatos do cliente`,
      hab4: `Bom gerenciamento de tempo para cumprir prazos`,
    },
    {
      resumo: `Busco uma oportunidade como Jovem Aprendiz, onde eu possa desenvolver minhas habilidades
profissionais e adquirir experiência prática no mercado de trabalho. Tenho facilidade para aprender, sou
proativo, organizado e gosto de trabalhar em equipe.

Sou estudante de Desenvolvimento de Sistemas, com experiência em design gráfico e interesse em atuar
em diferentes áreas. Possuo boa comunicação, atenção aos detalhes e organização. Tenho facilidade com
tecnologia, trabalho bem em equipe e sou adaptável a novos desafios. Busco uma oportunidade para
aplicar e expandir meus conhecimentos, contribuindo com a empresa de maneira eficiente e responsável.`,
    },
  ];

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        
        <Cabecalho />

        <Text style={styles.titulo}>Dados Pessoais</Text>
        <View style={styles.tarefas}>
          <text>ENDEREÇO:</text>
          <Informacoes dado={infos[0].endereco} />
          <br></br>
          <text>TELEFONE:</text>
          <Informacoes dado={infos[0].telefone} />
          <br></br>
          <text>EMAIL:</text>
          <Informacoes dado={infos[0].email} />
          <br></br>
          <text>SITE:</text>
          <Informacoes dado={infos[0].site} />
        </View>
        
        <Text style={styles.titulo}>Experiência Profissional</Text>
        <View style={styles.tarefas}>
          <Informacoes dado={infos[1].exp1}/>
          <Informacoes dado={infos[1].exp2}/>
        </View>

        <Text style={styles.titulo}>Formação Acadêmica</Text>
        <View style={styles.tarefas}>
          <Informacoes dado={infos[2].form1}/>
          <Informacoes dado={infos[2].form2}/>         
        </View>

        <Text style={styles.titulo}>Habilidades e Competências</Text>
        <View style={styles.tarefas}>
          <Informacoes dado={infos[3].hab1}/>
          <Informacoes dado={infos[3].hab2}/>
          <Informacoes dado={infos[3].hab3}/>
          <Informacoes dado={infos[3].hab4}/>
        </View>

        <Text style={styles.titulo}>Resumo</Text>
        <View style={styles.tarefas}>
          <Informacoes dado={infos[4].resumo}/>
        </View>  
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    paddingVertical: 20,
    alignItems: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: '#cec5c5ff',
    alignItems: 'center',
    width: '100%',
  },  
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  tarefas:{
    flexDirection: 'column', 
    alignItems: 'flex-start',
    width: '60%',
    marginBottom: 15,
    borderWidth: 1,
    borderColor: 'black',
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#ebebf0ff',
  }, 
});
