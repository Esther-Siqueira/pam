import { Text } from 'react-native';
import { styles } from './styles';

export function Cabecalho() {
  return (
    
      <Text style={styles.title}>LEONARDO ALVES SILVA</Text>
     
  );
}


