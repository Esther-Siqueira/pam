import { StyleSheet } from 'react-native';


export let styles = StyleSheet.create({
    title: {
      fontSize: 40,
      fontStyle: 'italic',
    }
});