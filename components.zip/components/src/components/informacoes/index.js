import { Text, View } from 'react-native';
import { styles } from './styles';
import { Fragment } from 'react/jsx-runtime';

export function Informacoes({ dado }) {
    return (
        <Fragment>
            <View style={styles.tarefas}>
                <Text style={styles.text}>{dado}</Text>
            </View>
        </Fragment>
    )

}