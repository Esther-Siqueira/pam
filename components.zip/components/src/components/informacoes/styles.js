import { StyleSheet } from 'react-native';

export let styles = StyleSheet.create({
  tarefas:{
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    borderWidth: 1,
    borderColor: 'black',
    padding: 10,
    borderRadius: 10,
    backgroundColor: '#ffffffff',
  }, 
  text:{
    flex: 1,
    fontSize: 14,
    textAlign: 'justify',
  }
});
